import { config } from 'dotenv';
config();

import '@/ai/flows/voice-assisted-input.ts';