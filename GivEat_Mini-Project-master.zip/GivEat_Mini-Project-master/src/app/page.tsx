import Link from "next/link";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Leaf } from "lucide-react";

export default function WelcomePage() {
  return (
    <div className="flex min-h-screen w-full flex-col items-center justify-center bg-background p-4">
      <Card className="w-full max-w-md shadow-lg border-2 border-primary/10">
        <CardHeader className="items-center text-center">
          <div className="flex items-center gap-2 text-primary">
            <Leaf className="h-8 w-8" />
            <h1 className="text-4xl font-bold font-headline">GivEat</h1>
          </div>
          <p className="text-muted-foreground pt-2 font-medium">
            Food connects hearts, not just homes
          </p>
        </CardHeader>
        <CardContent className="flex flex-col gap-4 p-6">
          <Button asChild size="lg" className="font-bold">
            <Link href="/home">Login with Phone/Email</Link>
          </Button>
          <Button asChild variant="outline" size="lg" className="font-bold border-primary/50 text-primary hover:bg-primary/10 hover:text-primary">
            <Link href="/home">Continue as Guest</Link>
          </Button>
        </CardContent>
      </Card>
    </div>
  );
}
